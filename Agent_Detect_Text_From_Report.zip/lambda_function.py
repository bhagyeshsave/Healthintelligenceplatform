import boto3
import json
import base64
import os

s3 = boto3.client("s3")
bedrock = boto3.client("bedrock-runtime")

INPUT_BUCKET = "med-document-input"
OUTPUT_BUCKET = "med-document-output"

MODEL_ARN = "arn:aws:bedrock:us-east-1:525856937873:inference-profile/global.anthropic.claude-sonnet-4-5-20250929-v1:0"


def lambda_handler(event, context):
    bucket = event.get("bucket", INPUT_BUCKET)
    key = event.get("key")
    output_filename = event.get("output_filename")

    if not key:
        return {"error": "Missing key"}

    print(f"Processing file: s3://{bucket}/{key}")

    file_bytes = s3.get_object(Bucket=bucket, Key=key)["Body"].read()
    _, ext = os.path.splitext(key)
    ext = ext.lower()

    extracted_text = extract_text_with_claude(file_bytes, ext)
    structured_json = convert_to_json_with_claude(extracted_text)

    # Use custom output filename if provided, otherwise default to input filename with .json extension
    if output_filename:
        # Ensure .json extension
        if not output_filename.endswith(".json"):
            output_filename += ".json"
        output_key = output_filename
    else:
        output_key = key.rsplit(".", 1)[0] + ".json"

    s3.put_object(
        Bucket=OUTPUT_BUCKET,
        Key=output_key,
        Body=json.dumps(structured_json, indent=2),
        ContentType="application/json"
    )

    return {
        "status": "success",
        "output_json_s3": f"s3://{OUTPUT_BUCKET}/{output_key}",
        "preview": structured_json
    }


def extract_text_with_claude(file_bytes, file_ext):
    print("Calling Claude Sonnet 4.5 for OCR...")

    encoded = base64.b64encode(file_bytes).decode("utf-8")

    is_pdf = file_ext == ".pdf"
    
    # Determine media type for images
    media_type_map = {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".gif": "image/gif",
        ".webp": "image/webp"
    }
    
    # Build content based on file type
    if is_pdf:
        content_block = {
            "type": "document",
            "source": {
                "type": "base64",
                "media_type": "application/pdf",
                "data": encoded
            }
        }
    else:
        # For images, use "image" type
        content_block = {
            "type": "image",
            "source": {
                "type": "base64",
                "media_type": media_type_map.get(file_ext, "image/jpeg"),
                "data": encoded
            }
        }

    payload = {
        "anthropic_version": "bedrock-2023-05-31",
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "Extract all readable text from this document and return ONLY plain text."
                    },
                    content_block
                ]
            }
        ],
        "max_tokens": 8000
    }

    response = bedrock.invoke_model(
        modelId=MODEL_ARN,
        body=json.dumps(payload)
    )

    result = json.loads(response["body"].read())

    extracted = ""
    for item in result.get("content", []):
        if "text" in item:
            extracted += item["text"]

    return extracted


def convert_to_json_with_claude(text):
    payload = {
        "anthropic_version": "bedrock-2023-05-31",
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text":
                            "Convert this medical text into structured JSON with fields: "
                            "patient_info, diagnoses, vitals, lab_results, prescriptions, notes.\n\n"
                            + text
                    }
                ]
            }
        ],
        "max_tokens": 6000
    }

    response = bedrock.invoke_model(
        modelId=MODEL_ARN,
        body=json.dumps(payload)
    )

    result = json.loads(response["body"].read())

    output = ""
    for item in result.get("content", []):
        if "text" in item:
            output += item["text"]

    # Clean JSON output
    cleaned_output = clean_json_response(output)

    try:
        return json.loads(cleaned_output)
    except:
        return {"raw_output": cleaned_output}


def clean_json_response(text):
    """Remove markdown code blocks and extract clean JSON"""
    # Remove ```json and ``` markers
    text = text.strip()
    
    # Remove leading ```json or ```
    if text.startswith("```json"):
        text = text[7:]
    elif text.startswith("```"):
        text = text[3:]
    
    # Remove trailing ```
    if text.endswith("```"):
        text = text[:-3]
    
    return text.strip()